import java.util.List;

public class SortingUtility implements SortingUtilityIF{
    public List<Product> sort(List<Product> items, int sortingApproach){
        if(sortingApproach == 1) {
            int n = items.size();
            for (int i = 0; i < n - 1; i++){
                for (int j = 0; j < n - i - 1; j++) {
                    if (items.get(j).getPrice() > items.get(j + 1).getPrice()) {
                        Product temp = items.get(j);
                        items.set(j, items.get(j + 1));
                        items.set(j + 1, temp);
                    }
                }
            }
        }else if(sortingApproach == 2){
            quickSort(items, 0, items.size() -1);
        }
        return items;
    }
    int partition(List<Product> list, int low, int high)
    {
        double pivot = list.get(high).getPrice();
        int i = (low-1); // index of smaller element
        for (int j=low; j<high; j++)
        {
            // If current element is smaller than the pivot
            if (list.get(j).getPrice() < pivot)
            {
                i++;

                // swap arr[i] and arr[j]
                Product temp = list.get(i);
                list.set(i,list.get(j));
                list.set(j, temp);
            }
        }
        // swap arr[i+1] and arr[high] (or pivot)
        Product temp = list.get(i+1);
        list.set(i+1, list.get(high));
        list.set(high, temp);

        return i+1;
    }
    void quickSort(List<Product> list, int low, int high)
    {
        if (low < high)
        {
            /* pi is partitioning index, arr[pi] is
              now at right place */
            int pi = partition(list, low, high);

            // Recursively sort elements before
            // partition and after partition
            quickSort(list, low, pi-1);
            quickSort(list, pi+1, high);
        }
    }
}
