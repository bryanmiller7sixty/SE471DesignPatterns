public class Product {
    private final String ID;
    private String name;
    private double price;
    public Product(String ID, String name, double price){
        this.ID = ID;
        this.name = name;
        this.price = price;
    }
    public String getID(){
        return ID;
    }
    public double getPrice(){
        return price;
    }
    public String getName(){
        return name;
    }
    public void setPrice(double price){
        this.price = price;
    }
}
