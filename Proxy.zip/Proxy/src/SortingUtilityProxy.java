import java.lang.reflect.Array;
import java.util.*;

public class SortingUtilityProxy implements SortingUtilityIF{
    private List<Product> listPro;
    private SortingUtilityIF util = new SortingUtility();
    public SortingUtilityProxy(){
        listPro= new ArrayList<Product>();
    }
    public void addProduct(Product pro){
        listPro.add(pro);
    }
    public List<Product> getList(){
        return this.listPro;
    }
    @Override
    public List<Product> sort(List<Product> items, int sortingApproach){
        if(sortingApproach == 1) {
            List<Product> list = util.sort(items, sortingApproach);
            for(Product p: items){
                System.out.println("ID: " + p.getID() + " Name: " + p.getName() + " Price: " + p.getPrice());
            }
        }else if(sortingApproach == 2){
            System.out.println(util.getClass().getName());
            util.sort(items, 2);
            for(Product p: items){
                System.out.println("Name: " + p.getName() + " ID: " + p.getID() + " Price: " + p.getPrice());
            }
        }
        return items;
    }
}

