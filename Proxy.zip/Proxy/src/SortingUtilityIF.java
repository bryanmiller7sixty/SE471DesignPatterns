import java.util.List;
public interface SortingUtilityIF {
    public List<Product> sort(List<Product> items, int sortingApproach);
}
