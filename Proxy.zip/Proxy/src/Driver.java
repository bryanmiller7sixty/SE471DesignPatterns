public class Driver {
    public static void main(String args[]){
        SortingUtilityProxy soP= new SortingUtilityProxy();
        soP.addProduct(new Product("123AD3", "Product1", 2.60));
        soP.addProduct(new Product("123AD4", "Product2", 4.70));
        soP.addProduct(new Product("123AD5", "Product3", 2.11));
        soP.addProduct(new Product("123AD6", "Product3", 96.01));
        soP.addProduct(new Product("123AD7", "Product3", 23.91));
        soP.sort(soP.getList(), 2);
    }
}
